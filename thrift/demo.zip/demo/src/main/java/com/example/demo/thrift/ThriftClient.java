package com.example.demo.thrift;

import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TFramedTransport;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import thrift.generated.Person;
import thrift.generated.PersonService;

public class ThriftClient {

    public static void main(String[] args) throws Exception {
        // 传输方式
        TTransport transport = new TFramedTransport(new TSocket("localhost", 8899), 30000);

        // 协议类型
        TProtocol protocol = new TBinaryProtocol(transport);

        // 客户端
        PersonService.Client client = new PersonService.Client(protocol);

        // 启动连接
        transport.open();

        // rpc调用
        Person person = client.getPersonByUsername("xm");
        System.out.println("client get: " + person.username);
        client.savePerson(person);

        // 关闭连接
        transport.close();
    }
}
