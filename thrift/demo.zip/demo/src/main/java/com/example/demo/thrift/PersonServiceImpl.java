package com.example.demo.thrift;

import org.apache.thrift.TException;
import thrift.generated.DataException;
import thrift.generated.Person;
import thrift.generated.PersonService;

public class PersonServiceImpl implements PersonService.Iface {
    @Override
    public Person getPersonByUsername(String username) throws DataException, TException {
        return new Person().setUsername(username).setAge(23).setMarrie(true);
    }

    @Override
    public void savePerson(Person person) throws TException {
        System.out.println("save person ...");

        System.out.println(person.username);
        System.out.println(person.age);
        System.out.println(person.marrie);
    }
}
