namespace java com.example.demo.thrift.generated

struct Person {
    1: optional string username,
    2: optional i32 age,
    3: optional bool marrie
}

exception DataException {
    1: optional string message,
    2: optional string callStack,
    3: optional string date
}

service PersonService {
    Person getPersonByUsername(1: required string username) throws (1: DataException data),
    void savePerson(1: required Person person)
}